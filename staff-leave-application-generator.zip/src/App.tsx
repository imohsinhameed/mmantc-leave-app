/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Printer,
  FileText,
  RotateCcw,
  Sparkles,
  Download,
  Plus,
  Trash2,
  Calendar,
  User,
  Building,
  Briefcase,
  Clock,
  CheckCircle2,
  HelpCircle,
  FileCheck,
  Eye,
  Sliders,
  Maximize2
} from 'lucide-react';

interface LectureArrangement {
  id: string;
  date: string;
  subjectClass: string;
  time: string;
  staffName: string;
}

interface LeaveFormData {
  staffName: string;
  designation: string;
  department: string;
  natureOfLeave: 'CL' | 'C-OFF' | 'ML' | 'EL' | 'OD' | 'LWP';
  coffDetails: string;
  reason: string;
  fromDate: string;
  toDate: string;
  numberOfDays: string;
  isHalfDay: boolean;
  halfDaySession: 'First Half (Morning)' | 'Second Half (Afternoon)';
  probableJoiningDate: string;
  applicationDate: string;
  alternateArrangements: LectureArrangement[];
  // Office Record
  totalLeaves: string;
  leavesAvailed: string;
  balanceLeaves: string;
  leavesApplied: string;
  clCurrentMonth: string;
  elCurrentMonth: string;
  mlCurrentMonth: string;
  lwpCurrentMonth: string;
  lastLeavePeriod: string;
  formNumber: string;
}

const INITIAL_DATA: LeaveFormData = {
  staffName: '',
  designation: 'Assistant Professor',
  department: 'Computer Engineering',
  natureOfLeave: 'CL',
  coffDetails: '',
  reason: '',
  fromDate: '',
  toDate: '',
  numberOfDays: '1',
  isHalfDay: false,
  halfDaySession: 'First Half (Morning)',
  probableJoiningDate: '',
  applicationDate: new Date().toISOString().split('T')[0],
  alternateArrangements: [
    { id: '1', date: '', subjectClass: '', time: '', staffName: '' },
    { id: '2', date: '', subjectClass: '', time: '', staffName: '' },
    { id: '3', date: '', subjectClass: '', time: '', staffName: '' },
  ],
  totalLeaves: '12',
  leavesAvailed: '2',
  balanceLeaves: '10',
  leavesApplied: '1',
  clCurrentMonth: '0',
  elCurrentMonth: '0',
  mlCurrentMonth: '0',
  lwpCurrentMonth: '0',
  lastLeavePeriod: '',
  formNumber: `LA-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
};

const SAMPLE_DATA: LeaveFormData = {
  staffName: 'Prof. Shaikh Mohammad Zubair',
  designation: 'Assistant Professor',
  department: 'Computer Engineering',
  natureOfLeave: 'CL',
  coffDetails: 'Worked on Sunday 04/10/2026 for NAAC documentation and SPPU exam duty',
  reason: 'Family function and urgent personal work at hometown',
  fromDate: '2026-10-18',
  toDate: '2026-10-19',
  numberOfDays: '2',
  isHalfDay: false,
  halfDaySession: 'First Half (Morning)',
  probableJoiningDate: '2026-10-20',
  applicationDate: '2026-10-14',
  alternateArrangements: [
    {
      id: '1',
      date: '18/10/2026',
      subjectClass: 'Cloud Computing (TE Comp)',
      time: '10:15 AM - 11:15 AM',
      staffName: 'Prof. Ansari Farhan',
    },
    {
      id: '2',
      date: '18/10/2026',
      subjectClass: 'Database Lab (BE Comp - B2)',
      time: '01:15 PM - 03:15 PM',
      staffName: 'Prof. Khan Rizwan',
    },
    {
      id: '3',
      date: '19/10/2026',
      subjectClass: 'Compiler Design (TE Comp)',
      time: '11:15 AM - 12:15 PM',
      staffName: 'Prof. Patel Imran',
    },
  ],
  totalLeaves: '12',
  leavesAvailed: '3',
  balanceLeaves: '9',
  leavesApplied: '2',
  clCurrentMonth: '1',
  elCurrentMonth: '0',
  mlCurrentMonth: '0',
  lwpCurrentMonth: '0',
  lastLeavePeriod: '15/09/2026 to 16/09/2026 (2 days)',
  formNumber: 'LA-2026-4821',
};

export default function App() {
  const [formData, setFormData] = useState<LeaveFormData>(() => {
    const saved = localStorage.getItem('mmantc_leave_draft');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_DATA;
  });

  const [activeTab, setActiveTab] = useState<'editor' | 'preview' | 'split'>('split');
  const [saveStatus, setSaveStatus] = useState<string>('');
  const printAreaRef = useRef<HTMLDivElement>(null);

  // Auto calculate number of days and probable joining date when fromDate or toDate change
  useEffect(() => {
    if (formData.fromDate && formData.toDate) {
      const from = new Date(formData.fromDate);
      const to = new Date(formData.toDate);
      if (!isNaN(from.getTime()) && !isNaN(to.getTime())) {
        const diffTime = to.getTime() - from.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        if (diffDays > 0) {
          const calculatedDays = formData.isHalfDay ? '0.5' : String(diffDays);
          setFormData((prev) => {
            // Also suggest probable joining date as next day after toDate
            const nextDay = new Date(to);
            nextDay.setDate(nextDay.getDate() + 1);
            const nextDayStr = nextDay.toISOString().split('T')[0];

            return {
              ...prev,
              numberOfDays: calculatedDays,
              leavesApplied: calculatedDays,
              probableJoiningDate: prev.probableJoiningDate || nextDayStr,
            };
          });
        }
      }
    }
  }, [formData.fromDate, formData.toDate, formData.isHalfDay]);

  const handleChange = (field: keyof LeaveFormData, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleArrangementChange = (index: number, field: keyof LectureArrangement, value: string) => {
    const updated = [...formData.alternateArrangements];
    updated[index] = { ...updated[index], [field]: value };
    setFormData((prev) => ({ ...prev, alternateArrangements: updated }));
  };

  const addArrangementRow = () => {
    setFormData((prev) => ({
      ...prev,
      alternateArrangements: [
        ...prev.alternateArrangements,
        {
          id: Date.now().toString(),
          date: '',
          subjectClass: '',
          time: '',
          staffName: '',
        },
      ],
    }));
  };

  const removeArrangementRow = (index: number) => {
    if (formData.alternateArrangements.length <= 1) return;
    setFormData((prev) => ({
      ...prev,
      alternateArrangements: prev.alternateArrangements.filter((_, i) => i !== index),
    }));
  };

  const handlePrint = () => {
    window.print();
  };

  const loadSample = () => {
    setFormData(SAMPLE_DATA);
    setSaveStatus('Sample data loaded!');
    setTimeout(() => setSaveStatus(''), 2500);
  };

  const clearForm = () => {
    if (confirm('Are you sure you want to clear the form?')) {
      setFormData(INITIAL_DATA);
      localStorage.removeItem('mmantc_leave_draft');
      setSaveStatus('Form cleared');
      setTimeout(() => setSaveStatus(''), 2500);
    }
  };

  const saveDraft = () => {
    localStorage.setItem('mmantc_leave_draft', JSON.stringify(formData));
    setSaveStatus('Draft saved locally!');
    setTimeout(() => setSaveStatus(''), 2500);
  };

  // Format date helper for print display (YYYY-MM-DD -> DD/MM/YYYY)
  const formatDateDisplay = (dateStr: string) => {
    if (!dateStr) return '';
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      return dateStr;
    } catch {
      return dateStr;
    }
  };

  // Generate self-contained standalone HTML single file
  const exportStandaloneHTML = () => {
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Leave Application - MMANTC</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Times New Roman', Times, serif; background: #e2e8f0; color: #000; padding: 15px; }
    .sheet { background: #fff; width: 210mm; min-height: 297mm; margin: 0 auto; padding: 8mm 10mm; box-shadow: 0 4px 15px rgba(0,0,0,0.15); }
    .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 4px; margin-bottom: 6px; }
    .logo-row { display: flex; align-items: center; justify-content: space-between; }
    .header h1 { font-size: 14pt; font-weight: bold; text-transform: uppercase; margin: 2px 0; }
    .header h2 { font-size: 10pt; font-weight: bold; }
    .header p { font-size: 7.5pt; line-height: 1.2; }
    .title-banner { text-align: center; margin: 6px 0; font-size: 12pt; font-weight: bold; text-decoration: underline; letter-spacing: 1px; }
    .content-line { font-size: 9.5pt; margin: 4px 0; display: flex; align-items: baseline; line-height: 1.4; }
    .underline-val { border-bottom: 1px solid #000; flex-grow: 1; padding: 0 4px; font-weight: bold; min-height: 14px; }
    table { width: 100%; border-collapse: collapse; margin: 6px 0; font-size: 8.5pt; }
    table, th, td { border: 1px solid #000; }
    th { background: #f8fafc; font-weight: bold; text-align: center; padding: 4px 3px; }
    td { padding: 4px 4px; }
    .sig-row { display: flex; justify-content: space-between; margin-top: 14px; font-size: 9pt; font-weight: bold; }
    .office-box { border: 1px solid #000; padding: 6px; margin: 8px 0; font-size: 8pt; }
    .tear-line { border-top: 1px dashed #000; margin: 10px 0 6px 0; text-align: center; position: relative; font-size: 7.5pt; }
    .tear-line span { background: #fff; padding: 0 8px; position: relative; top: -7px; }
    .ack-box { font-size: 8.5pt; }
    .footer-box { border: 1px solid #000; font-size: 6.5pt; text-align: center; padding: 3px; margin-top: 6px; line-height: 1.2; }
    .btn-bar { text-align: center; margin-bottom: 15px; }
    .btn { background: #1e3a8a; color: #fff; border: none; padding: 8px 16px; font-size: 14px; border-radius: 4px; cursor: pointer; font-family: sans-serif; font-weight: bold; }
    @media print {
      body { background: #fff; padding: 0; }
      .sheet { box-shadow: none; padding: 0; width: 100%; }
      .btn-bar { display: none; }
      @page { size: A4 portrait; margin: 8mm; }
    }
  </style>
</head>
<body>
  <div class="btn-bar">
    <button class="btn" onclick="window.print()">Print Leave Application</button>
  </div>
  <div class="sheet">
    <div class="header">
      <div style="font-size: 8pt; font-weight: bold; letter-spacing: 0.5px;">Al Jamia Mohammadia Education Society's</div>
      <h1>MAULANA MUKHTAR AHMAD NADVI TECHNICAL CAMPUS</h1>
      <p style="font-weight: bold; margin: 1px 0;">Approved by AICTE, New Delhi | Recognised by DTE, Mumbai & Govt. of Maharashtra | Affiliated to Savitribai Phule Pune University, Pune</p>
      <p>Mansoora P.O. Box. No. 144, Malegaon, Dist. Nashik, Pin: 423203 (MS) | Contact: +91-9028254526 | Email: info@mmantc.edu.in | Web: www.mmantc.edu.in</p>
    </div>
    <div class="title-banner">LEAVE APPLICATION</div>
    <div style="display: flex; justify-content: space-between; font-size: 8.5pt; margin-bottom: 4px;">
      <div><strong>Form No:</strong> ${formData.formNumber}</div>
      <div><strong>Application Date:</strong> ${formatDateDisplay(formData.applicationDate)}</div>
    </div>
    <div class="content-line"><span>1. Name of Staff:</span><span class="underline-val">${formData.staffName || '&nbsp;'}</span></div>
    <div style="display:flex; gap: 12px;">
      <div class="content-line" style="flex:1;"><span>2. Designation:</span><span class="underline-val">${formData.designation || '&nbsp;'}</span></div>
      <div class="content-line" style="flex:1;"><span>3. Department:</span><span class="underline-val">${formData.department || '&nbsp;'}</span></div>
    </div>
    <div class="content-line"><span>4. Nature of Leave:</span><span class="underline-val">[ ${formData.natureOfLeave} ] (${['CL','C-OFF','ML','EL','OD','LWP'].map(t => t === formData.natureOfLeave ? '✔ ' + t : t).join(' / ')})</span></div>
    <div class="content-line"><span>5. If C-OFF, mention details:</span><span class="underline-val">${formData.coffDetails || '&nbsp;'}</span></div>
    <div class="content-line"><span>6. Reason for leave:</span><span class="underline-val">${formData.reason || '&nbsp;'}</span></div>
    <div style="display:flex; gap: 12px;">
      <div class="content-line" style="flex:2;"><span>7. Period of leave: From</span><span class="underline-val">${formatDateDisplay(formData.fromDate)}</span><span>To</span><span class="underline-val">${formatDateDisplay(formData.toDate)}</span></div>
      <div class="content-line" style="flex:1;"><span>No. of Days:</span><span class="underline-val">${formData.numberOfDays || '&nbsp;'}</span></div>
    </div>
    <div class="content-line"><span>8. Probable Date of joining:</span><span class="underline-val">${formatDateDisplay(formData.probableJoiningDate) || '&nbsp;'}</span></div>

    <div style="font-size: 8.5pt; font-weight: bold; margin-top: 6px;">9. Alternate Lecture / Lab Arrangements:</div>
    <table>
      <thead>
        <tr>
          <th style="width: 25px;">Sr.</th>
          <th style="width: 85px;">Date</th>
          <th>Subject with Class</th>
          <th style="width: 110px;">Time</th>
          <th>Alternate Staff Name</th>
          <th style="width: 70px;">Sign</th>
        </tr>
      </thead>
      <tbody>
        ${formData.alternateArrangements.map((row, idx) => `
          <tr>
            <td style="text-align: center;">${idx + 1}</td>
            <td style="text-align: center;">${row.date}</td>
            <td>${row.subjectClass}</td>
            <td style="text-align: center;">${row.time}</td>
            <td>${row.staffName}</td>
            <td></td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="sig-row" style="margin-top: 18px;">
      <div>Signature of Applicant</div>
      <div>HOD / Coordinator</div>
    </div>

    <div class="office-box" style="margin-top: 10px;">
      <div style="font-weight: bold; text-align: center; margin-bottom: 4px; text-decoration: underline;">FOR OFFICE RECORD ONLY</div>
      <table style="margin: 0; font-size: 7.5pt;">
        <tr>
          <th>Total Leaves</th><th>Availed</th><th>Balance</th><th>Applied</th><th>Current Month CL</th><th>EL</th><th>ML</th><th>LWP</th>
        </tr>
        <tr style="text-align: center;">
          <td>${formData.totalLeaves}</td>
          <td>${formData.leavesAvailed}</td>
          <td>${formData.balanceLeaves}</td>
          <td>${formData.leavesApplied}</td>
          <td>${formData.clCurrentMonth}</td>
          <td>${formData.elCurrentMonth}</td>
          <td>${formData.mlCurrentMonth}</td>
          <td>${formData.lwpCurrentMonth}</td>
        </tr>
      </table>
      <div style="font-size: 7.5pt; margin-top: 4px;">Last leave taken: ${formData.lastLeavePeriod || 'NIL'}</div>
      <div class="sig-row" style="margin-top: 14px; font-size: 8pt;">
        <div>Dealing Clerk</div>
        <div>Admin Off / O.S.</div>
        <div>Sanctioned / Not Sanctioned<br><strong>PRINCIPAL</strong></div>
      </div>
    </div>

    <div class="tear-line"><span>✂ Tear along this dotted line ✂</span></div>

    <div class="ack-box">
      <div style="text-align: center; font-weight: bold; font-size: 9.5pt; text-decoration: underline;">ACKNOWLEDGMENT SLIP</div>
      <div style="display: flex; justify-content: space-between; margin-top: 2px;">
        <span><strong>Staff Name:</strong> ${formData.staffName}</span>
        <span><strong>Dept:</strong> ${formData.department}</span>
        <span><strong>Nature of Leave:</strong> ${formData.natureOfLeave}</span>
      </div>
      <div style="display: flex; justify-content: space-between; margin-top: 3px;">
        <span><strong>Period:</strong> ${formatDateDisplay(formData.fromDate)} to ${formatDateDisplay(formData.toDate)}</span>
        <span><strong>Days:</strong> ${formData.numberOfDays}</span>
        <span><strong>Form No:</strong> ${formData.formNumber}</span>
      </div>
      <div style="display: flex; justify-content: space-between; margin-top: 10px; font-size: 8pt; border-top: 1px dotted #888; padding-top: 4px;">
        <span>Received By (Name & Sign): ___________________</span>
        <span>Date: ___________</span>
        <span>Official Stamp: [ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ]</span>
      </div>
    </div>

    <div class="footer-box">
      Head Office: Jamia Mohammadia Education Society, G4, Mastan Shopping Centre, Clare Road, Mirza Galib Marg, Byculla, Mumbai-08 | Tel: 022-23081702 / 23093782 | Email: jmesmumbai@gmail.com | Website: www.jmes.org.in
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MMANTC_Leave_Application_${formData.staffName.replace(/\s+/g, '_') || 'Form'}.html`;
    a.click();
    URL.revokeObjectURL(url);
    setSaveStatus('Standalone HTML downloaded!');
    setTimeout(() => setSaveStatus(''), 2500);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800">
      {/* Top Application Header Bar (Hidden in Print) */}
      <header className="no-print bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-lg text-white shadow-inner">
              M
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-base sm:text-lg leading-tight tracking-wide">
                  MMANTC Staff Leave Portal
                </h1>
                <span className="hidden sm:inline-block text-[10px] bg-emerald-500/20 text-emerald-300 font-semibold px-2 py-0.5 rounded border border-emerald-500/30">
                  A4 Print-Ready
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Al Jamia Mohammadia Education Society &bull; Malegaon Campus
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center flex-wrap gap-2">
            {/* View Mode Switcher for larger screens */}
            <div className="hidden lg:flex bg-slate-800 p-0.5 rounded-lg border border-slate-700 text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('split')}
                className={`px-3 py-1.5 rounded-md transition font-medium ${
                  activeTab === 'split' ? 'bg-slate-700 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Split View
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('editor')}
                className={`px-3 py-1.5 rounded-md transition font-medium ${
                  activeTab === 'editor' ? 'bg-slate-700 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Form Editor
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-1.5 rounded-md transition font-medium ${
                  activeTab === 'preview' ? 'bg-slate-700 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                A4 Preview
              </button>
            </div>

            <button
              type="button"
              onClick={loadSample}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md border border-slate-700 transition"
              title="Fill form with sample faculty details"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Sample Data</span>
            </button>

            <button
              type="button"
              onClick={exportStandaloneHTML}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md border border-slate-700 transition"
              title="Download self-contained single HTML file"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Export HTML</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md shadow-sm transition active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Generate PDF</span>
            </button>
          </div>
        </div>

        {/* Mobile Tab Toggle */}
        <div className="lg:hidden flex border-t border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('editor')}
            className={`flex-1 py-2 text-center font-medium ${
              activeTab === 'editor' ? 'bg-slate-800 text-white border-b-2 border-blue-500' : 'text-slate-400'
            }`}
          >
            Form Editor
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`flex-1 py-2 text-center font-medium ${
              activeTab === 'preview' ? 'bg-slate-800 text-white border-b-2 border-blue-500' : 'text-slate-400'
            }`}
          >
            A4 Sheet Preview
          </button>
        </div>
      </header>

      {/* Status banner */}
      {saveStatus && (
        <div className="no-print bg-emerald-600 text-white text-xs py-1.5 px-4 text-center font-medium animate-fadeIn">
          {saveStatus}
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 lg:p-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* LEFT: Form Editor Panel */}
          <div
            className={`no-print ${
              activeTab === 'preview' ? 'hidden' : activeTab === 'split' ? 'lg:col-span-5 xl:col-span-5' : 'lg:col-span-12'
            }`}
          >
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="bg-slate-50 px-5 py-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h2 className="font-semibold text-slate-800 text-base flex items-center gap-2">
                    <FileText className="w-4 h-4 text-blue-600" />
                    Leave Application Details
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Fill the fields below to update the A4 print sheet in real-time
                  </p>
                </div>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={saveDraft}
                    className="text-xs px-2.5 py-1 text-slate-600 hover:text-slate-900 bg-white border border-slate-300 rounded hover:bg-slate-100 transition"
                    title="Save current inputs to browser memory"
                  >
                    Save Draft
                  </button>
                  <button
                    type="button"
                    onClick={clearForm}
                    className="text-xs px-2.5 py-1 text-rose-600 hover:text-rose-700 bg-white border border-slate-300 rounded hover:bg-rose-50 transition"
                    title="Reset all fields"
                  >
                    Reset
                  </button>
                </div>
              </div>

              <div className="p-5 space-y-6 max-h-[calc(100vh-180px)] overflow-y-auto">
                {/* 1. Staff Details */}
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 pb-1 border-b border-slate-100">
                    <User className="w-3.5 h-3.5 text-blue-600" />
                    1. Staff Details
                  </div>
                  <div className="grid grid-cols-1 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Full Name of Staff <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Dr. Aamir Khan / Prof. Shaikh Mohammed"
                        value={formData.staffName}
                        onChange={(e) => handleChange('staffName', e.target.value)}
                        className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Designation <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={formData.designation}
                          onChange={(e) => handleChange('designation', e.target.value)}
                          className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="Professor">Professor</option>
                          <option value="Associate Professor">Associate Professor</option>
                          <option value="Assistant Professor">Assistant Professor</option>
                          <option value="Lecturer">Lecturer</option>
                          <option value="HOD">HOD</option>
                          <option value="Workshop Superintendent">Workshop Superintendent</option>
                          <option value="Technical Assistant / Lab Assistant">Technical / Lab Assistant</option>
                          <option value="Librarian / Asst. Librarian">Librarian / Asst. Librarian</option>
                          <option value="Office Superintendent / Clerk">Office Superintendent / Clerk</option>
                          <option value="Accountant">Accountant</option>
                          <option value="Supporting Staff">Supporting Staff</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Department <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={formData.department}
                          onChange={(e) => handleChange('department', e.target.value)}
                          className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="Computer Engineering">Computer Engineering</option>
                          <option value="Mechanical Engineering">Mechanical Engineering</option>
                          <option value="Civil Engineering">Civil Engineering</option>
                          <option value="Electrical Engineering">Electrical Engineering</option>
                          <option value="Electronics & Telecommunication">Electronics & Telecom</option>
                          <option value="Applied Sciences & Humanities">Applied Sciences & Humanities</option>
                          <option value="Pharmacy">Pharmacy</option>
                          <option value="Administration / Office">Administration / Office</option>
                          <option value="Library">Library</option>
                          <option value="Workshop">Workshop</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Leave Nature & Reason */}
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 pb-1 border-b border-slate-100">
                    <Briefcase className="w-3.5 h-3.5 text-blue-600" />
                    2. Leave Nature & Reason
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1.5">
                      Nature of Leave <span className="text-rose-500">*</span>
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                      {(['CL', 'C-OFF', 'ML', 'EL', 'OD', 'LWP'] as const).map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => handleChange('natureOfLeave', type)}
                          className={`py-1.5 px-2 text-xs font-semibold rounded-md border text-center transition ${
                            formData.natureOfLeave === type
                              ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      CL: Casual Leave &bull; C-OFF: Compensatory Off &bull; ML: Medical Leave &bull; EL: Earned Leave &bull; OD: On Duty &bull; LWP: Leave Without Pay
                    </p>
                  </div>

                  {formData.natureOfLeave === 'C-OFF' && (
                    <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                      <label className="block text-xs font-semibold text-amber-900 mb-1">
                        If C-OFF, mention details (Date worked & Duty performed) <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Worked on Sunday 04/10/2026 for SPPU Exam Duty / NAAC work"
                        value={formData.coffDetails}
                        onChange={(e) => handleChange('coffDetails', e.target.value)}
                        className="w-full text-xs rounded border border-amber-300 px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Reason for Leave <span className="text-rose-500">*</span>
                    </label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Attending national conference / Personal urgent work at hometown / Medical reasons"
                      value={formData.reason}
                      onChange={(e) => handleChange('reason', e.target.value)}
                      className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* 3. Dates & Period */}
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 pb-1 border-b border-slate-100">
                    <Calendar className="w-3.5 h-3.5 text-blue-600" />
                    3. Period of Leave
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        From Date <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="date"
                        value={formData.fromDate}
                        onChange={(e) => handleChange('fromDate', e.target.value)}
                        className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        To Date <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="date"
                        value={formData.toDate}
                        onChange={(e) => handleChange('toDate', e.target.value)}
                        className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-medium text-slate-700">
                          Number of Days
                        </label>
                        <label className="flex items-center gap-1 text-[11px] text-slate-600 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formData.isHalfDay}
                            onChange={(e) => handleChange('isHalfDay', e.target.checked)}
                            className="rounded text-blue-600 focus:ring-blue-500 h-3.5 w-3.5"
                          />
                          Half Day (0.5)
                        </label>
                      </div>
                      <input
                        type="text"
                        value={formData.numberOfDays}
                        onChange={(e) => {
                          handleChange('numberOfDays', e.target.value);
                          handleChange('leavesApplied', e.target.value);
                        }}
                        className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Probable Date of Joining
                      </label>
                      <input
                        type="date"
                        value={formData.probableJoiningDate}
                        onChange={(e) => handleChange('probableJoiningDate', e.target.value)}
                        className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Application Date
                      </label>
                      <input
                        type="date"
                        value={formData.applicationDate}
                        onChange={(e) => handleChange('applicationDate', e.target.value)}
                        className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Form / Serial No.
                      </label>
                      <input
                        type="text"
                        value={formData.formNumber}
                        onChange={(e) => handleChange('formNumber', e.target.value)}
                        className="w-full text-sm rounded-lg border border-slate-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>

                {/* 4. Alternate Lecture Arrangements Table */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                    <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700">
                      <Clock className="w-3.5 h-3.5 text-blue-600" />
                      4. Alternate Lecture / Lab Arrangements
                    </div>
                    <button
                      type="button"
                      onClick={addArrangementRow}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700 hover:bg-blue-50 px-2 py-0.5 rounded transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add Row
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-500">
                    Specify substituting faculty members for missed lectures or practical sessions.
                  </p>

                  <div className="space-y-2.5">
                    {formData.alternateArrangements.map((row, index) => (
                      <div
                        key={row.id}
                        className="p-3 bg-slate-50 rounded-lg border border-slate-200 relative group"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-bold text-slate-600">
                            Slot #{index + 1}
                          </span>
                          {formData.alternateArrangements.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeArrangementRow(index)}
                              className="text-slate-400 hover:text-rose-500 transition"
                              title="Delete row"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                          <div>
                            <input
                              type="text"
                              placeholder="Date (e.g. 18/10/2026)"
                              value={row.date}
                              onChange={(e) => handleArrangementChange(index, 'date', e.target.value)}
                              className="w-full rounded border border-slate-300 px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>

                          <div>
                            <input
                              type="text"
                              placeholder="Time (e.g. 10:15 - 11:15 AM)"
                              value={row.time}
                              onChange={(e) => handleArrangementChange(index, 'time', e.target.value)}
                              className="w-full rounded border border-slate-300 px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <input
                              type="text"
                              placeholder="Subject with Class (e.g. Operating Systems - TE Comp)"
                              value={row.subjectClass}
                              onChange={(e) => handleArrangementChange(index, 'subjectClass', e.target.value)}
                              className="w-full rounded border border-slate-300 px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <input
                              type="text"
                              placeholder="Alternate Staff Name (e.g. Prof. Ansari Farhan)"
                              value={row.staffName}
                              onChange={(e) => handleArrangementChange(index, 'staffName', e.target.value)}
                              className="w-full rounded border border-slate-300 px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 5. Office Record (Pre-fill / Optional) */}
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 pb-1 border-b border-slate-100">
                    <Building className="w-3.5 h-3.5 text-blue-600" />
                    5. Office Record (Establishment Section)
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-0.5">
                        Total Leaves
                      </label>
                      <input
                        type="text"
                        value={formData.totalLeaves}
                        onChange={(e) => handleChange('totalLeaves', e.target.value)}
                        className="w-full text-xs rounded border border-slate-300 px-2 py-1.5 text-center focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-0.5">
                        Availed Till Date
                      </label>
                      <input
                        type="text"
                        value={formData.leavesAvailed}
                        onChange={(e) => handleChange('leavesAvailed', e.target.value)}
                        className="w-full text-xs rounded border border-slate-300 px-2 py-1.5 text-center focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-0.5">
                        Balance Leaves
                      </label>
                      <input
                        type="text"
                        value={formData.balanceLeaves}
                        onChange={(e) => handleChange('balanceLeaves', e.target.value)}
                        className="w-full text-xs rounded border border-slate-300 px-2 py-1.5 text-center focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-0.5">
                        Leaves Applied
                      </label>
                      <input
                        type="text"
                        value={formData.leavesApplied}
                        onChange={(e) => handleChange('leavesApplied', e.target.value)}
                        className="w-full text-xs rounded border border-slate-300 px-2 py-1.5 text-center focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      Leaves taken during current month:
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-500 block text-center">C/L</span>
                        <input
                          type="text"
                          value={formData.clCurrentMonth}
                          onChange={(e) => handleChange('clCurrentMonth', e.target.value)}
                          className="w-full text-xs rounded border border-slate-300 px-2 py-1 text-center"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block text-center">E/L</span>
                        <input
                          type="text"
                          value={formData.elCurrentMonth}
                          onChange={(e) => handleChange('elCurrentMonth', e.target.value)}
                          className="w-full text-xs rounded border border-slate-300 px-2 py-1 text-center"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block text-center">M/L</span>
                        <input
                          type="text"
                          value={formData.mlCurrentMonth}
                          onChange={(e) => handleChange('mlCurrentMonth', e.target.value)}
                          className="w-full text-xs rounded border border-slate-300 px-2 py-1 text-center"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block text-center">LWP</span>
                        <input
                          type="text"
                          value={formData.lwpCurrentMonth}
                          onChange={(e) => handleChange('lwpCurrentMonth', e.target.value)}
                          className="w-full text-xs rounded border border-slate-300 px-2 py-1 text-center"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      Period of Last Leave Taken
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 15/09/2026 to 16/09/2026 (2 days)"
                      value={formData.lastLeavePeriod}
                      onChange={(e) => handleChange('lastLeavePeriod', e.target.value)}
                      className="w-full text-xs rounded border border-slate-300 px-2.5 py-1.5"
                    />
                  </div>
                </div>

                {/* Primary Action Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handlePrint}
                    className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-sm flex items-center justify-center gap-2 transition"
                  >
                    <Printer className="w-5 h-5" />
                    Preview & Generate PDF / Print
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: A4 Printable Sheet Live Preview */}
          <div
            className={`${
              activeTab === 'editor' ? 'hidden' : activeTab === 'split' ? 'lg:col-span-7 xl:col-span-7' : 'lg:col-span-12'
            } flex flex-col items-center`}
          >
            {/* Preview Toolbar (Hidden in Print) */}
            <div className="no-print w-full flex items-center justify-between pb-3 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span className="font-semibold text-slate-700">Official A4 Paper Layout</span>
                <span>(Matches Institutional Print Template)</span>
              </div>
              <button
                type="button"
                onClick={handlePrint}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-white border border-slate-300 rounded hover:bg-slate-50 font-medium text-slate-700 shadow-xs"
              >
                <Printer className="w-3.5 h-3.5 text-blue-600" />
                Print A4 Sheet
              </button>
            </div>

            {/* A4 Sheet Container */}
            <div className="print-area-wrapper w-full overflow-x-auto flex justify-center pb-8">
              <div
                ref={printAreaRef}
                className="institutional-sheet a4-preview-container bg-white text-black p-6 sm:p-7 md:p-8 border border-slate-300 flex flex-col justify-between"
                style={{
                  width: '210mm',
                  minHeight: '297mm',
                  boxSizing: 'border-box',
                  fontSize: '9.5pt',
                  lineHeight: '1.3',
                }}
              >
                {/* Upper Main Application Section */}
                <div>
                  {/* Institutional Header */}
                  <div className="header-box border-b-2 border-black pb-2 mb-2 relative">
                    <div className="flex items-start justify-between gap-2">
                      {/* Left: Emblem / Crest SVG */}
                      <div className="w-14 h-14 flex-shrink-0 flex items-center justify-center pt-1">
                        <svg
                          viewBox="0 0 100 100"
                          className="w-13 h-13 text-black stroke-current fill-none"
                          style={{ strokeWidth: 2 }}
                        >
                          {/* Academic Shield & Technical Gear Motif */}
                          <path
                            d="M 50,5 L 85,20 L 85,55 C 85,75 50,95 50,95 C 50,95 15,75 15,55 L 15,20 Z"
                            fill="#ffffff"
                            stroke="#000000"
                            strokeWidth="3"
                          />
                          {/* Inner Gear */}
                          <circle cx="50" cy="45" r="14" stroke="#000" strokeWidth="2" strokeDasharray="3,2" />
                          <circle cx="50" cy="45" r="7" fill="#000" />
                          {/* Open Book */}
                          <path
                            d="M 32,70 Q 50,62 50,72 Q 50,62 68,70 L 68,78 Q 50,70 50,80 Q 50,70 32,78 Z"
                            fill="#000"
                          />
                          {/* Torch / Flame at top */}
                          <path d="M 50,22 Q 55,27 50,33 Q 45,27 50,22 Z" fill="#000" />
                        </svg>
                      </div>

                      {/* Center: Main Institutional Branding */}
                      <div className="text-center flex-1 px-1">
                        <div
                          className="institutional-sans uppercase font-bold text-[8.5pt] tracking-wider text-black"
                          style={{ letterSpacing: '0.5px' }}
                        >
                          Al Jamia Mohammadia Education Society&apos;s
                        </div>
                        <h1 className="institutional-sans font-extrabold text-[12.5pt] sm:text-[13pt] uppercase text-black leading-tight tracking-tight my-0.5">
                          MAULANA MUKHTAR AHMAD NADVI TECHNICAL CAMPUS
                        </h1>
                        <p className="text-[7pt] sm:text-[7.5pt] font-semibold text-black leading-snug">
                          Approved by AICTE, New Delhi | Recognised by DTE, Mumbai &amp; Govt. of Maharashtra | Affiliated to Savitribai Phule Pune University, Pune
                        </p>
                        <p className="text-[6.5pt] sm:text-[7pt] text-black leading-snug mt-0.5">
                          Mansoora P.O. Box. No. 144, Malegaon, Dist. Nashik, Pin: 423203 (MS) | Contact: +91-9028254526 | Email: info@mmantc.edu.in | www.mmantc.edu.in
                        </p>
                      </div>

                      {/* Right: Technical Campus Monogram */}
                      <div className="w-14 h-14 flex-shrink-0 flex flex-col items-center justify-center border border-black p-1 text-center bg-slate-50">
                        <span className="font-extrabold text-[10pt] leading-tight font-serif">MMANTC</span>
                        <span className="text-[5.5pt] font-sans font-bold uppercase leading-none mt-0.5">Mansoora</span>
                        <span className="text-[5pt] font-sans text-slate-700 leading-none">Malegaon</span>
                      </div>
                    </div>
                  </div>

                  {/* Title Bar */}
                  <div className="text-center my-2">
                    <span className="inline-block border-2 border-black px-6 py-0.5 font-bold text-[12pt] tracking-wider uppercase bg-white">
                      LEAVE APPLICATION
                    </span>
                  </div>

                  {/* Meta: Form Number & Application Date */}
                  <div className="flex justify-between items-center text-[8.5pt] font-bold mb-2 pb-1 border-b border-dashed border-slate-300">
                    <div>
                      <span>Form No: </span>
                      <span className="font-mono text-black underline underline-offset-2">
                        {formData.formNumber || '________________'}
                      </span>
                    </div>
                    <div>
                      <span>Application Date: </span>
                      <span className="font-mono text-black underline underline-offset-2">
                        {formatDateDisplay(formData.applicationDate) || '____/____/________'}
                      </span>
                    </div>
                  </div>

                  {/* Formal Salutation */}
                  <div className="text-[8.5pt] mb-2 leading-tight">
                    <div className="font-bold">To,</div>
                    <div className="font-bold">The Principal,</div>
                    <div>Maulana Mukhtar Ahmad Nadvi Technical Campus, Mansoora, Malegaon.</div>
                    <div className="mt-1 italic">
                      Respected Sir, I request you to kindly sanction my leave as per the details mentioned below:
                    </div>
                  </div>

                  {/* Fill-in Blanks Content Form */}
                  <div className="space-y-1.5 text-[9pt]">
                    {/* Line 1: Staff Name */}
                    <div className="flex items-baseline gap-1">
                      <span className="font-bold whitespace-nowrap">1. Name of Staff:</span>
                      <div className="border-b border-black flex-1 font-bold px-2 pb-0.5 text-black min-h-[18px]">
                        {formData.staffName || ''}
                      </div>
                    </div>

                    {/* Line 2: Designation & Department */}
                    <div className="flex flex-wrap items-baseline gap-2">
                      <div className="flex items-baseline gap-1 flex-1 min-w-[200px]">
                        <span className="font-bold whitespace-nowrap">2. Designation:</span>
                        <div className="border-b border-black flex-1 font-bold px-2 pb-0.5 text-black min-h-[18px]">
                          {formData.designation}
                        </div>
                      </div>
                      <div className="flex items-baseline gap-1 flex-1 min-w-[200px]">
                        <span className="font-bold whitespace-nowrap">3. Department:</span>
                        <div className="border-b border-black flex-1 font-bold px-2 pb-0.5 text-black min-h-[18px]">
                          {formData.department}
                        </div>
                      </div>
                    </div>

                    {/* Line 3: Nature of Leave with standard option checkboxes */}
                    <div className="flex items-baseline gap-2 pt-0.5">
                      <span className="font-bold whitespace-nowrap">4. Nature of Leave:</span>
                      <div className="flex-1 flex flex-wrap items-center gap-3 font-bold border-b border-black pb-0.5 px-2">
                        {(['CL', 'C-OFF', 'ML', 'EL', 'OD', 'LWP'] as const).map((type) => (
                          <span key={type} className="inline-flex items-center gap-1">
                            <span className="inline-block w-3 h-3 border border-black text-[9pt] leading-none text-center font-bold">
                              {formData.natureOfLeave === type ? '✓' : ''}
                            </span>
                            <span>{type}</span>
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Line 4: If C-OFF Details */}
                    <div className="flex items-baseline gap-1">
                      <span className="font-bold whitespace-nowrap">5. If C-OFF, mention details:</span>
                      <div className="border-b border-black flex-1 px-2 pb-0.5 text-black min-h-[18px]">
                        {formData.natureOfLeave === 'C-OFF' ? formData.coffDetails || 'N/A' : formData.coffDetails || 'N/A'}
                      </div>
                    </div>

                    {/* Line 5: Reason for Leave */}
                    <div className="flex items-baseline gap-1">
                      <span className="font-bold whitespace-nowrap">6. Reason for leave:</span>
                      <div className="border-b border-black flex-1 font-bold px-2 pb-0.5 text-black min-h-[18px]">
                        {formData.reason || ''}
                      </div>
                    </div>

                    {/* Line 6: Period of Leave (From / To) & Total Days */}
                    <div className="flex flex-wrap items-baseline gap-2 pt-0.5">
                      <div className="flex items-baseline gap-1 flex-1 min-w-[220px]">
                        <span className="font-bold whitespace-nowrap">7. Period of leave: From</span>
                        <span className="border-b border-black px-2 pb-0.5 font-bold min-w-[85px] text-center">
                          {formatDateDisplay(formData.fromDate) || '___/___/______'}
                        </span>
                        <span className="font-bold whitespace-nowrap">To</span>
                        <span className="border-b border-black px-2 pb-0.5 font-bold min-w-[85px] text-center">
                          {formatDateDisplay(formData.toDate) || '___/___/______'}
                        </span>
                      </div>
                      <div className="flex items-baseline gap-1">
                        <span className="font-bold whitespace-nowrap">No. of Days:</span>
                        <span className="border-b border-black px-3 pb-0.5 font-bold text-center min-w-[45px]">
                          {formData.numberOfDays || '___'}
                        </span>
                        {formData.isHalfDay && (
                          <span className="text-[7.5pt] italic text-slate-700">({formData.halfDaySession})</span>
                        )}
                      </div>
                    </div>

                    {/* Line 7: Probable Date of Joining */}
                    <div className="flex items-baseline gap-1">
                      <span className="font-bold whitespace-nowrap">8. Probable Date of joining:</span>
                      <div className="border-b border-black flex-1 px-2 pb-0.5 font-bold min-h-[18px]">
                        {formatDateDisplay(formData.probableJoiningDate) || '____/____/________'}
                      </div>
                    </div>
                  </div>

                  {/* Alternate Arrangements Table */}
                  <div className="mt-3">
                    <div className="font-bold text-[8.5pt] mb-1">
                      9. Alternate Lecture / Lab Arrangements:
                    </div>
                    <table className="w-full border-collapse border border-black text-[8pt]">
                      <thead>
                        <tr className="bg-slate-100">
                          <th className="border border-black px-1.5 py-1 text-center font-bold w-7">Sr.</th>
                          <th className="border border-black px-2 py-1 text-center font-bold w-24">Date</th>
                          <th className="border border-black px-2 py-1 text-center font-bold">Subject with Class</th>
                          <th className="border border-black px-2 py-1 text-center font-bold w-28">Time</th>
                          <th className="border border-black px-2 py-1 text-center font-bold">
                            Alternate Arrangement (Staff Name)
                          </th>
                          <th className="border border-black px-2 py-1 text-center font-bold w-16">Signature</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formData.alternateArrangements.map((item, idx) => (
                          <tr key={item.id} className="h-7">
                            <td className="border border-black px-1 py-1 text-center font-bold">{idx + 1}</td>
                            <td className="border border-black px-1.5 py-1 text-center">{item.date}</td>
                            <td className="border border-black px-2 py-1">{item.subjectClass}</td>
                            <td className="border border-black px-1.5 py-1 text-center">{item.time}</td>
                            <td className="border border-black px-2 py-1 font-semibold">{item.staffName}</td>
                            <td className="border border-black px-1 py-1 text-center"></td>
                          </tr>
                        ))}
                        {/* Always ensure minimum 3 rows rendered for clean paper aesthetics */}
                        {formData.alternateArrangements.length < 3 &&
                          Array.from({ length: 3 - formData.alternateArrangements.length }).map((_, i) => (
                            <tr key={`empty-${i}`} className="h-7">
                              <td className="border border-black px-1 py-1 text-center">
                                {formData.alternateArrangements.length + i + 1}
                              </td>
                              <td className="border border-black"></td>
                              <td className="border border-black"></td>
                              <td className="border border-black"></td>
                              <td className="border border-black"></td>
                              <td className="border border-black"></td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Applicant & HOD Signatures Row */}
                  <div className="flex justify-between items-end mt-7 px-4 text-[8.5pt]">
                    <div className="text-center">
                      <div className="w-40 border-t border-black pt-1 font-bold">
                        Signature of Applicant
                      </div>
                      <div className="text-[7pt] text-slate-600 mt-0.5">Date: {formatDateDisplay(formData.applicationDate)}</div>
                    </div>
                    <div className="text-center">
                      <div className="w-44 border-t border-black pt-1 font-bold">
                        HOD / Coordinator
                      </div>
                      <div className="text-[7pt] text-slate-600 mt-0.5">Recommended / Forwarded</div>
                    </div>
                  </div>

                  {/* Office Record & Sanction Section */}
                  <div className="mt-4 border border-black p-2 bg-white">
                    <div className="text-center font-bold text-[8pt] tracking-wider uppercase border-b border-black pb-1 mb-1.5">
                      FOR OFFICE RECORD &amp; SANCTION ONLY
                    </div>

                    <table className="w-full border-collapse border border-black text-[7.5pt] mb-1.5">
                      <thead>
                        <tr className="bg-slate-50 text-center font-bold">
                          <th className="border border-black py-0.5 px-1">Total Leaves</th>
                          <th className="border border-black py-0.5 px-1">Leaves Availed</th>
                          <th className="border border-black py-0.5 px-1">Balance Leaves</th>
                          <th className="border border-black py-0.5 px-1">Leaves Applied</th>
                          <th className="border border-black py-0.5 px-1" colSpan={4}>
                            Leaves Taken During Current Month
                          </th>
                        </tr>
                        <tr className="bg-slate-50 text-center text-[7pt]">
                          <th className="border border-black"></th>
                          <th className="border border-black"></th>
                          <th className="border border-black"></th>
                          <th className="border border-black"></th>
                          <th className="border border-black py-0.5">C/L</th>
                          <th className="border border-black py-0.5">E/L</th>
                          <th className="border border-black py-0.5">M/L</th>
                          <th className="border border-black py-0.5">LWP</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="text-center h-6 font-bold">
                          <td className="border border-black">{formData.totalLeaves || '12'}</td>
                          <td className="border border-black">{formData.leavesAvailed || '0'}</td>
                          <td className="border border-black">{formData.balanceLeaves || '12'}</td>
                          <td className="border border-black">{formData.leavesApplied || formData.numberOfDays || '1'}</td>
                          <td className="border border-black">{formData.clCurrentMonth || '0'}</td>
                          <td className="border border-black">{formData.elCurrentMonth || '0'}</td>
                          <td className="border border-black">{formData.mlCurrentMonth || '0'}</td>
                          <td className="border border-black">{formData.lwpCurrentMonth || '0'}</td>
                        </tr>
                      </tbody>
                    </table>

                    <div className="text-[7.5pt] flex items-baseline gap-1 mb-3">
                      <span className="font-bold">Period of last leave taken:</span>
                      <span className="border-b border-black flex-1 px-2 font-medium">
                        {formData.lastLeavePeriod || 'NIL'}
                      </span>
                    </div>

                    {/* Official Signatures Row */}
                    <div className="flex justify-between items-end pt-3 text-[8pt] px-2 font-bold">
                      <div className="text-center">
                        <div className="w-28 border-t border-black pt-1">Dealing Clerk</div>
                      </div>
                      <div className="text-center">
                        <div className="w-32 border-t border-black pt-1">Admin Off / O.S.</div>
                      </div>
                      <div className="text-center">
                        <div className="text-[7pt] mb-1 font-normal">[ Sanctioned / Not Sanctioned ]</div>
                        <div className="w-36 border-t border-black pt-1 uppercase">PRINCIPAL</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Lower Acknowledgment Slip (Tear-off style) */}
                <div className="mt-4 pt-1">
                  {/* Dotted Cut Line */}
                  <div className="relative text-center my-1">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-dashed border-black"></div>
                    </div>
                    <span className="relative bg-white px-3 text-[7.5pt] font-mono text-slate-700">
                      ✂ - - - - - - - - - - - - - - - - - Tear along this line (Acknowledgment Slip) - - - - - - - - - - - - - - - - - ✂
                    </span>
                  </div>

                  {/* Acknowledgment Slip Content Box */}
                  <div className="border border-black p-2 bg-white text-[8pt]">
                    <div className="flex items-center justify-between border-b border-black pb-1 mb-1.5">
                      <div className="font-bold uppercase text-[8pt]">
                        MMANTC, Mansoora, Malegaon
                      </div>
                      <div className="font-bold text-[9pt] uppercase underline tracking-wider">
                        ACKNOWLEDGMENT
                      </div>
                      <div className="font-mono text-[7.5pt]">
                        Form No: <span className="font-bold">{formData.formNumber || '______'}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-1 gap-x-2 text-[8pt]">
                      <div>
                        <span className="font-bold">Name of Staff: </span>
                        <span className="font-semibold underline underline-offset-2">
                          {formData.staffName || '________________'}
                        </span>
                      </div>
                      <div>
                        <span className="font-bold">Department: </span>
                        <span>{formData.department}</span>
                      </div>
                      <div>
                        <span className="font-bold">Nature of Leave: </span>
                        <span className="font-bold">{formData.natureOfLeave}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="font-bold">Period of Leave: </span>
                        <span>From </span>
                        <span className="font-semibold">{formatDateDisplay(formData.fromDate) || '___/___/______'}</span>
                        <span> To </span>
                        <span className="font-semibold">{formatDateDisplay(formData.toDate) || '___/___/______'}</span>
                      </div>
                      <div>
                        <span className="font-bold">No. of Days: </span>
                        <span className="font-bold">{formData.numberOfDays || '___'}</span>
                      </div>
                    </div>

                    {/* Receipt Footer */}
                    <div className="flex flex-wrap items-center justify-between gap-2 mt-2 pt-1 border-t border-dotted border-slate-400 text-[7.5pt]">
                      <div>
                        <span>Received By :- Name of Staff: </span>
                        <span className="inline-block w-28 border-b border-black"></span>
                      </div>
                      <div>
                        <span>Sign: </span>
                        <span className="inline-block w-20 border-b border-black"></span>
                      </div>
                      <div>
                        <span>Received Date: </span>
                        <span className="inline-block w-20 border-b border-black"></span>
                      </div>
                      <div>
                        <span>Form No: </span>
                        <span className="font-bold">{formData.formNumber || '_____'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Institutional Head Office Footer Box */}
                  <div className="border border-black mt-1 p-1 text-center text-[6pt] sm:text-[6.5pt] leading-tight font-sans text-slate-800">
                    <span className="font-bold">Head Office: </span>
                    Jamia Mohammadia Education Society, G4, Mastan Shopping Centre, Clare Road, Mirza Galib Marg, Byculla, Mumbai-08 | Tel: 022-23081702 / 23093782 | Email: jmesmumbai@gmail.com | Website: www.jmes.org.in
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer Info (Hidden in Print) */}
      <footer className="no-print bg-slate-900 text-slate-400 text-xs py-3 border-t border-slate-800 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            Maulana Mukhtar Ahmad Nadvi Technical Campus (MMANTC) &bull; Staff Leave Management
          </div>
          <div className="text-[11px] text-slate-500">
            Complies with Standard A4 Institutional Paper Format &bull; AICTE / DTE / SPPU Pune
          </div>
        </div>
      </footer>
    </div>
  );
}
